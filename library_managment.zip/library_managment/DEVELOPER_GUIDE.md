# Library Management System - Developer Guide

## 📋 Table of Contents
1. [Project Overview](#project-overview)
2. [Technology Stack](#technology-stack)
3. [Project Architecture](#project-architecture)
4. [Django Structure (MVT Pattern)](#django-structure-mvt-pattern)
5. [Database Models](#database-models)
6. [Business Logic & Views](#business-logic--views)
7. [Forms & Validation](#forms--validation)
8. [Templates & Frontend](#templates--frontend)
9. [Authentication & Authorization](#authentication--authorization)
10. [File Handling](#file-handling)
11. [Key Features Implementation](#key-features-implementation)
12. [Code Patterns & Best Practices](#code-patterns--best-practices)

---

## 🎯 Project Overview

This is a **Django-based Library Management System** that allows administrators to manage books, authors, genres, and track book borrowings. Regular users can browse books, borrow them, and access book content (PDFs/documents) after borrowing.

### Core Functionality
- **Book Management**: CRUD operations for books with cover images and content files
- **Author & Genre Management**: Organize books by authors and genres
- **Borrowing System**: Track book borrowings with due dates
- **User Authentication**: Registration, login, and role-based access control
- **Content Access Control**: Users can only view/download book content after borrowing
- **Search & Filter**: Search books by title, author, ISBN, or filter by genre

---

## 🛠 Technology Stack

### Backend
- **Python 3.8+**: Core programming language
- **Django 4.2.7**: Web framework (MVT architecture)
- **SQLite**: Default database (can be switched to PostgreSQL/MySQL)

### Libraries & Dependencies
```python
Django==4.2.7          # Web framework
Pillow>=10.2.0         # Image processing for book covers
```

### Frontend
- **HTML5**: Markup
- **CSS3**: Custom dark theme styling
- **Django Templates**: Server-side rendering with template inheritance

### Development Tools
- **Django Admin**: Built-in admin interface for data management
- **Django ORM**: Database abstraction layer

---

## 🏗 Project Architecture

### Directory Structure
```
library_managment/
├── library/                    # Main Django app
│   ├── models.py              # Database models
│   ├── views.py               # View functions (business logic)
│   ├── forms.py               # Form definitions
│   ├── urls.py                # URL routing
│   ├── admin.py               # Admin configuration
│   ├── templates/             # HTML templates
│   │   └── library/
│   ├── management/            # Custom management commands
│   │   └── commands/
│   └── migrations/            # Database migrations
├── library_project/           # Django project settings
│   ├── settings.py            # Project configuration
│   ├── urls.py                # Root URL configuration
│   └── wsgi.py                # WSGI configuration
├── static/                    # Static files (CSS, JS, images)
│   └── css/
│       └── style.css
├── media/                     # User-uploaded files
│   ├── book_covers/          # Book cover images
│   └── book_content/         # Book PDFs/documents
├── manage.py                  # Django management script
└── requirements.txt           # Python dependencies
```

---

## 📐 Django Structure (MVT Pattern)

Django follows the **Model-View-Template (MVT)** pattern:

### 1. **Models** (`models.py`)
- Define database schema
- Handle data validation at the model level
- Contain business logic in model methods

### 2. **Views** (`views.py`)
- Handle HTTP requests
- Process business logic
- Return HTTP responses (render templates or redirects)

### 3. **Templates** (`templates/`)
- HTML files with Django template syntax
- Display data from views
- Handle user interface

### 4. **URLs** (`urls.py`)
- Map URLs to view functions
- Define URL patterns and parameters

---

## 🗄 Database Models

### Model Relationships
```
Author (1) ──< (Many) Book
Genre  (1) ──< (Many) Book
Book   (1) ──< (Many) Borrowing
```

### 1. **Author Model**
```python
class Author(models.Model):
    name = models.CharField(max_length=200)
    bio = models.TextField(blank=True, null=True)
    birth_date = models.DateField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
```

**Python/Django Usage:**
- `CharField`: Text field with max length constraint
- `TextField`: Large text field for biography
- `DateField`: Date storage
- `auto_now_add=True`: Automatically set timestamp on creation

**Logic:**
- One author can have many books (ForeignKey relationship)
- Ordered by name alphabetically (`ordering = ['name']`)

### 2. **Genre Model**
```python
class Genre(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
```

**Python/Django Usage:**
- `unique=True`: Ensures no duplicate genre names
- `blank=True, null=True`: Field is optional

### 3. **Book Model** (Core Model)
```python
class Book(models.Model):
    STATUS_CHOICES = [
        ('available', 'Available'),
        ('borrowed', 'Borrowed'),
        ('reserved', 'Reserved'),
    ]
    
    title = models.CharField(max_length=300)
    author = models.ForeignKey(Author, on_delete=models.CASCADE, related_name='books')
    isbn = models.CharField(max_length=13, unique=True, blank=True, null=True)
    genre = models.ForeignKey(Genre, on_delete=models.SET_NULL, null=True, related_name='books')
    total_copies = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    available_copies = models.PositiveIntegerField(default=1)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='available')
    cover_image = models.ImageField(upload_to='book_covers/', blank=True, null=True)
    content_file = models.FileField(upload_to='book_content/', blank=True, null=True)
```

**Python/Django Usage:**
- `ForeignKey`: Many-to-one relationship (many books to one author/genre)
- `on_delete=models.CASCADE`: Delete book if author is deleted
- `on_delete=models.SET_NULL`: Set genre to NULL if genre is deleted
- `related_name='books'`: Access author's books via `author.books.all()`
- `PositiveIntegerField`: Only positive numbers
- `MinValueValidator(1)`: Ensures at least 1 copy
- `ImageField`: Handles image uploads (requires Pillow)
- `FileField`: Handles file uploads (PDFs, documents)
- `upload_to`: Directory where files are stored

**Business Logic in Model:**
```python
def save(self, *args, **kwargs):
    # Auto-update status based on available copies
    if self.available_copies == 0:
        self.status = 'borrowed'
    else:
        self.status = 'available'
    super().save(*args, **kwargs)
```

**Logic Explanation:**
- Overrides Django's default `save()` method
- Automatically updates book status when saved
- If no copies available → status = 'borrowed'
- If copies available → status = 'available'
- This ensures status is always synchronized with availability

### 4. **Borrowing Model**
```python
class Borrowing(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE, related_name='borrowings')
    borrower_name = models.CharField(max_length=200)
    borrower_email = models.EmailField()
    borrower_phone = models.CharField(max_length=20, blank=True, null=True)
    borrow_date = models.DateField(default=timezone.now)
    return_date = models.DateField(blank=True, null=True)
    due_date = models.DateField()
    is_returned = models.BooleanField(default=False)
```

**Python/Django Usage:**
- `EmailField`: Validates email format
- `default=timezone.now`: Sets current date as default
- `BooleanField`: True/False flag for return status

**Business Logic:**
```python
def save(self, *args, **kwargs):
    if self.is_returned and not self.return_date:
        self.return_date = timezone.now().date()
        # Increase available copies when book is returned
        self.book.available_copies += 1
        self.book.save()
    super().save(*args, **kwargs)
```

**Logic Explanation:**
- When a book is marked as returned:
  1. Sets return_date to current date
  2. Increments book's available_copies
  3. Saves the book (which triggers status update)

---

## 🎮 Business Logic & Views

### View Function Pattern
```python
def view_name(request, pk=None):
    if request.method == 'POST':
        # Handle form submission
        form = FormClass(request.POST, request.FILES)
        if form.is_valid():
            # Process data
            form.save()
            return redirect('success_url')
    else:
        # Display form or data
        form = FormClass()
    
    context = {'form': form, ...}
    return render(request, 'template.html', context)
```

### Key Views Explained

#### 1. **Home View** (`home()`)
```python
def home(request):
    total_books = Book.objects.count()
    total_authors = Author.objects.count()
    total_genres = Genre.objects.count()
    borrowed_books = Borrowing.objects.filter(is_returned=False).count()
    available_books = Book.objects.filter(status='available').count()
    recent_books = Book.objects.all()[:6]
```

**Django ORM Usage:**
- `.count()`: Returns number of records
- `.filter()`: Filters queryset based on conditions
- `[:6]`: Python slicing to get first 6 books
- `.all()`: Gets all records

**Logic:**
- Aggregates statistics for dashboard
- Shows recent books (latest 6)

#### 2. **Book List View** (`book_list()`)
```python
def book_list(request):
    form = SearchForm(request.GET)
    books = Book.objects.all()
    
    if form.is_valid():
        query = form.cleaned_data.get('query')
        genre = form.cleaned_data.get('genre')
        
        if query:
            books = books.filter(
                Q(title__icontains=query) |
                Q(author__name__icontains=query) |
                Q(isbn__icontains=query) |
                Q(description__icontains=query)
            )
        
        if genre:
            books = books.filter(genre=genre)
    
    paginator = Paginator(books, 12)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
```

**Django ORM Usage:**
- `Q()` objects: Complex queries with OR conditions
- `__icontains`: Case-insensitive contains search
- `__name__icontains`: Search in related model (author's name)
- `Paginator`: Django pagination utility
- `.get_page()`: Gets page object with pagination info

**Logic:**
- Implements search across multiple fields (title, author, ISBN, description)
- Filters by genre if selected
- Paginates results (12 books per page)

#### 3. **Borrowing Create View** (`borrowing_create()`)
```python
def borrowing_create(request, book_pk=None):
    book = None
    if book_pk:
        book = get_object_or_404(Book, pk=book_pk)
    
    if request.method == 'POST':
        form = BorrowingForm(request.POST)
        if form.is_valid():
            borrowing = form.save(commit=False)
            if book:
                borrowing.book = book
            # Auto-fill user info if not admin
            if not request.user.is_staff:
                borrowing.borrower_name = request.user.get_full_name() or request.user.username
                borrowing.borrower_email = request.user.email
            # Decrease available copies
            borrowing.book.available_copies -= 1
            borrowing.book.save()
            borrowing.save()
```

**Python/Django Usage:**
- `get_object_or_404()`: Gets object or returns 404 error
- `form.save(commit=False)`: Creates object but doesn't save to DB yet
- `request.user`: Current logged-in user (Django auth)
- `.is_staff`: Checks if user is admin
- `or` operator: Fallback value (`get_full_name() or username`)

**Logic:**
- Can be called with or without a specific book
- Auto-fills borrower info for regular users
- Decreases available copies when book is borrowed
- Saves book (triggers status update)

#### 4. **Book Content View** (`book_content_view()`)
```python
@login_required
def book_content_view(request, pk):
    book = get_object_or_404(Book, pk=pk)
    
    if not book.content_file:
        raise Http404("Book content not available")
    
    # Check if user has borrowed this book
    if not request.user.is_staff:
        has_borrowed = Borrowing.objects.filter(
            book=book,
            borrower_email=request.user.email,
            is_returned=False
        ).exists()
        
        if not has_borrowed:
            messages.error(request, 'You must borrow this book first.')
            return redirect('book_detail', pk=book.pk)
    
    file_path = book.content_file.path
    response = FileResponse(open(file_path, 'rb'), content_type='application/pdf')
    response['Content-Disposition'] = f'inline; filename="{book.content_file.name}"'
    return response
```

**Python/Django Usage:**
- `@login_required`: Decorator requiring authentication
- `Http404`: Raises 404 error
- `.exists()`: Checks if queryset has any results
- `FileResponse`: Returns file as HTTP response
- `'rb'`: Read binary mode (for files)
- `Content-Disposition`: HTTP header for file display/download

**Logic:**
- Access control: Only borrowers can view content
- Admins bypass access control
- Returns file with appropriate content type
- `inline`: Displays in browser, `attachment`: Downloads

---

## 📝 Forms & Validation

### Form Structure
```python
class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'author', ...]
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
        }
    
    def clean(self):
        cleaned_data = super().clean()
        # Custom validation
        return cleaned_data
```

### Custom Validation Example
```python
def clean(self):
    cleaned_data = super().clean()
    total_copies = cleaned_data.get('total_copies')
    available_copies = cleaned_data.get('available_copies')
    
    if total_copies and available_copies and available_copies > total_copies:
        raise ValidationError('Available copies cannot exceed total copies.')
    
    return cleaned_data
```

**Python/Django Usage:**
- `clean()`: Custom form validation method
- `super().clean()`: Calls parent validation first
- `cleaned_data.get()`: Safely gets field value
- `ValidationError`: Raises validation error

**Logic:**
- Ensures data integrity at form level
- Prevents invalid data from being saved

### Borrowing Form Validation
```python
def clean_book(self):
    book = self.cleaned_data.get('book')
    if book and book.available_copies == 0:
        raise ValidationError('This book is not available for borrowing.')
    return book
```

**Logic:**
- Field-level validation (validates single field)
- Prevents borrowing unavailable books

---

## 🎨 Templates & Frontend

### Template Inheritance
```django
<!-- base.html -->
<html>
<head>...</head>
<body>
    {% block content %}{% endblock %}
</body>
</html>

<!-- child.html -->
{% extends 'library/base.html' %}
{% block content %}
    <!-- Page content -->
{% endblock %}
```

**Django Template Usage:**
- `{% extends %}`: Inherits from base template
- `{% block %}`: Defines replaceable sections
- `{{ variable }}`: Displays variable value
- `{% if %}`, `{% for %}`: Control flow

### Template Tags & Filters
```django
{{ book.available_copies|pluralize:"copy,copies" }}
{{ book.birth_date|date:"Y" }}
{{ book.books.count }}
```

**Django Template Usage:**
- `|pluralize`: Handles singular/plural forms
- `|date`: Formats dates
- `.count`: Counts related objects

### Conditional Display
```django
{% if book.available_copies > 0 %}
    <span class="badge badge-available">Available: {{ book.available_copies }} {{ book.available_copies|pluralize:"copy,copies" }}</span>
{% else %}
    <span class="badge badge-{{ book.status }}">{{ book.get_status_display }}</span>
{% endif %}
```

**Logic:**
- Shows available count if copies exist
- Shows status badge if no copies available

---

## 🔐 Authentication & Authorization

### User Roles
1. **Anonymous Users**: Can browse books, must login to borrow
2. **Regular Users**: Can borrow books, view their borrowings
3. **Staff/Admin**: Full access to all features

### Decorators Used

#### `@login_required`
```python
@login_required
def borrowing_create(request):
    # Only logged-in users can access
```

**Django Usage:**
- Redirects to login if user not authenticated
- Preserves `next` parameter for redirect after login

#### `@user_passes_test`
```python
def is_admin(user):
    return user.is_authenticated and user.is_staff

@user_passes_test(is_admin)
def book_create(request):
    # Only admins can access
```

**Python/Django Usage:**
- Custom permission check function
- Returns True/False based on user properties
- Decorator enforces permission

### Access Control in Views
```python
# Regular users see only their borrowings
if request.user.is_staff:
    borrowings = Borrowing.objects.all()
else:
    borrowings = Borrowing.objects.filter(borrower_email=request.user.email)
```

**Logic:**
- Conditional queryset filtering based on user role
- Admins see all, users see only their own

---

## 📁 File Handling

### File Upload Configuration
```python
# settings.py
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')
```

### Model File Fields
```python
cover_image = models.ImageField(upload_to='book_covers/', blank=True, null=True)
content_file = models.FileField(upload_to='book_content/', blank=True, null=True)
```

**Django Usage:**
- `upload_to`: Subdirectory within MEDIA_ROOT
- Files stored in: `media/book_covers/` and `media/book_content/`
- `ImageField`: Requires Pillow library

### File Serving in Development
```python
# urls.py (project level)
from django.conf import settings
from django.conf.urls.static import static

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
```

**Logic:**
- Serves uploaded files during development
- In production, use web server (Nginx/Apache) to serve media files

### File Access Control
```python
# Check if user can access file
if not request.user.is_staff:
    has_borrowed = Borrowing.objects.filter(
        book=book,
        borrower_email=request.user.email,
        is_returned=False
    ).exists()
```

**Logic:**
- Verifies user has borrowed book before allowing file access
- Admins bypass this check

---

## ⚙️ Key Features Implementation

### 1. **Automatic Status Management**

**Location:** `models.py` - `Book.save()`

**Logic:**
```python
def save(self, *args, **kwargs):
    if self.available_copies == 0:
        self.status = 'borrowed'
    else:
        self.status = 'available'
    super().save(*args, **kwargs)
```

**How it works:**
- Triggered automatically on every save
- Updates status based on available copies
- Ensures data consistency

### 2. **Copy Management**

**Borrowing Logic:**
```python
# Decrease copies when borrowing
borrowing.book.available_copies -= 1
borrowing.book.save()  # Triggers status update
```

**Return Logic:**
```python
# Increase copies when returning
self.book.available_copies += 1
self.book.save()  # Triggers status update
```

**Logic:**
- Copies decremented on borrow
- Copies incremented on return
- Status automatically updated via `save()` method

### 3. **Search Functionality**

**Implementation:**
```python
books = books.filter(
    Q(title__icontains=query) |
    Q(author__name__icontains=query) |
    Q(isbn__icontains=query) |
    Q(description__icontains=query)
)
```

**Django ORM:**
- `Q()` objects: Complex queries
- `|` operator: OR condition
- `__icontains`: Case-insensitive search
- `__name__`: Access related model field

### 4. **Pagination**

**Implementation:**
```python
paginator = Paginator(books, 12)
page_number = request.GET.get('page')
page_obj = paginator.get_page(page_number)
```

**Django Usage:**
- `Paginator`: Divides queryset into pages
- `get_page()`: Handles invalid page numbers gracefully
- Template uses `page_obj` for navigation

### 5. **Content Access Control**

**Implementation:**
```python
# Check borrowing status
has_borrowed = Borrowing.objects.filter(
    book=book,
    borrower_email=request.user.email,
    is_returned=False
).exists()

if not has_borrowed and not request.user.is_staff:
    # Deny access
```

**Logic:**
- Checks if user has active (not returned) borrowing
- Admins bypass check
- Prevents unauthorized content access

---

## 💡 Code Patterns & Best Practices

### 1. **DRY (Don't Repeat Yourself)**
- Template inheritance for common layout
- Reusable form classes
- Model methods for business logic

### 2. **Separation of Concerns**
- Models: Data structure and validation
- Views: Business logic and request handling
- Templates: Presentation layer
- Forms: User input validation

### 3. **Error Handling**
```python
book = get_object_or_404(Book, pk=pk)  # Returns 404 if not found
if not book.content_file:
    raise Http404("Book content not available")
```

### 4. **Security Practices**
- CSRF protection (Django default)
- User authentication checks
- File access control
- SQL injection prevention (ORM handles this)

### 5. **Python Best Practices**
- Type hints (can be added)
- Docstrings for functions
- Meaningful variable names
- Consistent code formatting

### 6. **Django Best Practices**
- Use `get_object_or_404()` instead of try/except
- Use `messages` framework for user feedback
- Use `related_name` for reverse relationships
- Use `select_related()` and `prefetch_related()` for optimization (can be added)

---

## 🔧 Custom Management Command

### Update Book Status Command
**Location:** `library/management/commands/update_book_status.py`

**Purpose:** Update existing books' status based on new logic

**Usage:**
```bash
python manage.py update_book_status
```

**Implementation:**
```python
def handle(self, *args, **options):
    books = Book.objects.all()
    for book in books:
        old_status = book.status
        book.save()  # Triggers status update
        if old_status != book.status:
            # Log changes
```

**Logic:**
- Iterates through all books
- Calls `save()` to trigger status update
- Logs changes for tracking

---

## 📊 Database Queries & Optimization

### Common Query Patterns

#### Get all books by author:
```python
author.books.all()  # Using related_name
Book.objects.filter(author=author)  # Direct query
```

#### Count related objects:
```python
author.books.count()  # Efficient count
len(author.books.all())  # Less efficient (loads all)
```

#### Filter with related fields:
```python
Book.objects.filter(author__name__icontains='John')
```

### Query Optimization (Future Improvements)
```python
# Use select_related for ForeignKey
books = Book.objects.select_related('author', 'genre').all()

# Use prefetch_related for reverse ForeignKey
authors = Author.objects.prefetch_related('books').all()
```

---

## 🚀 Deployment Considerations

### Settings for Production
```python
DEBUG = False
ALLOWED_HOSTS = ['yourdomain.com']
SECRET_KEY = os.environ.get('SECRET_KEY')
```

### Static Files
- Run `python manage.py collectstatic`
- Serve via web server (Nginx/Apache) or CDN

### Media Files
- Serve via web server, not Django
- Consider cloud storage (AWS S3, etc.)

### Database
- Switch from SQLite to PostgreSQL/MySQL
- Use connection pooling
- Regular backups

---

## 📚 Additional Resources

### Django Documentation
- [Django Models](https://docs.djangoproject.com/en/4.2/topics/db/models/)
- [Django Views](https://docs.djangoproject.com/en/4.2/topics/http/views/)
- [Django Forms](https://docs.djangoproject.com/en/4.2/topics/forms/)
- [Django Templates](https://docs.djangoproject.com/en/4.2/topics/templates/)

### Python Concepts Used
- Object-Oriented Programming (classes, inheritance)
- Decorators (`@login_required`, `@user_passes_test`)
- Context managers (file handling)
- List comprehensions (can be used for optimization)

---

## 🎓 Learning Points

### For Developers New to Django:
1. **MVT Pattern**: Understand how Models, Views, and Templates interact
2. **ORM**: Learn Django's database abstraction layer
3. **URL Routing**: How URLs map to views
4. **Template System**: Server-side rendering with Django templates
5. **Forms**: Handling user input and validation
6. **Authentication**: Django's built-in user system

### For Developers New to Python:
1. **Classes & Objects**: Model definitions
2. **Decorators**: Function wrappers for authentication
3. **Context Managers**: File handling
4. **List/Dict Comprehensions**: Data manipulation
5. **Exception Handling**: Error management

---

## 📝 Summary

This Library Management System demonstrates:
- **Django MVT architecture** in practice
- **Python OOP** concepts (models, classes, methods)
- **Database relationships** (ForeignKey, One-to-Many)
- **Business logic** in models and views
- **User authentication** and authorization
- **File handling** and access control
- **Form validation** and error handling
- **Template inheritance** and reusability

The codebase follows Django best practices and Python conventions, making it maintainable and scalable for future enhancements.

---

**Last Updated:** 2025
**Django Version:** 4.2.7
**Python Version:** 3.8+

